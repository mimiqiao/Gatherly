export const FEISHU_CONFIG = {
  APP_ID: 'cli_a7fc0e59d938100c',
  APP_SECRET: 'OIWOlxV9TKzDYrobnPmgdfACg8lRa42k',
  BASE_ID: 'VVGIbSMr7aPoqEsYg0Kc7noCn3c',
  TABLE_ID: 'tblr92PoZbPIw6OJ'
}; 